
import * as React from 'react';

const AdminScreen = () => {
    // Admin functionality has been removed.
    return null;
};

export default AdminScreen;
