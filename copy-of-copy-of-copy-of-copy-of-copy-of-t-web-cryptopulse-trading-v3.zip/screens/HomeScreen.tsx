
import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import { CreditCard, Download, Scale, Headset, Volume2 } from 'lucide-react';
import type { CryptoCoin } from '../types.ts';

const carouselImages = [
    'https://storage.googleapis.com/production-colab-notebook-images-data/uploads/2024_7_17/841029c9-6c84-473d-88b0-8b1b2414704b.jpg',
    'https://storage.googleapis.com/production-colab-notebook-images-data/uploads/2024_7_17/9a373307-2856-42d4-a801-b223fdc2b9a7.jpg',
    'https://storage.googleapis.com/production-colab-notebook-images-data/uploads/2024_7_17/e9e6b4d3-0668-45a7-9596-f033c4d516aa.jpg',
    'https://storage.googleapis.com/production-colab-notebook-images-data/uploads/2024_7_17/a3311654-72b1-46bb-9bd9-e331c15f9b9f.jpg',
    'https://storage.googleapis.com/production-colab-notebook-images-data/uploads/2024_7_17/bd8b2a3c-5893-470a-a0f1-460d37e6f827.jpg',
];

const commodityData: CryptoCoin[] = [
    { id: 'gold', symbol: 'XAU', name: 'Gold', image: '', current_price: 2318.50, price_change_percentage_24h: 0.48, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'silver', symbol: 'XAG', name: 'Silver', image: '', current_price: 29.50, price_change_percentage_24h: -0.06, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'oil', symbol: 'WTI', name: 'Crude Oil', image: '', current_price: 80.25, price_change_percentage_24h: 15.25, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'natural-gas', symbol: 'NG', name: 'Natural Gas', image: '', current_price: 2.91, price_change_percentage_24h: 0.00, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
    { id: 'corn', symbol: 'CORN', name: 'Corn', image: '', current_price: 450.75, price_change_percentage_24h: -7.06, market_cap: 0, market_cap_rank: 0, total_volume: 0, high_24h: null, low_24h: null },
];


const actionMenuItems = [
    { icon: CreditCard, label: 'Recharge', path: '/profile', state: { view: 'deposit' } },
    { icon: Download, label: 'Withdraw', path: '/profile', state: { view: 'withdraw' } },
    { icon: Scale, label: 'Balance', path: '/profile', state: {} },
    { icon: Headset, label: 'Consult', path: '/assistant' },
];

const HomeScreen = () => {
    const navigate = useNavigate();
    const [activeTab, setActiveTab] = React.useState('Hot');
    const [marketData, setMarketData] = React.useState<CryptoCoin[]>([]);
    const [loading, setLoading] = React.useState(true);
    const [currentImageIndex, setCurrentImageIndex] = React.useState(0);

    React.useEffect(() => {
        const timer = setInterval(() => {
            setCurrentImageIndex((prevIndex) =>
                prevIndex === carouselImages.length - 1 ? 0 : prevIndex + 1
            );
        }, 5000); // Change image every 5 seconds

        return () => clearInterval(timer);
    }, []);

    React.useEffect(() => {
        const fetchCoinData = async () => {
            setLoading(true);
            try {
                const response = await fetch('https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false');
                if (!response.ok) {
                    throw new Error('Failed to fetch data');
                }
                const data: CryptoCoin[] = await response.json();
                setMarketData(data);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };

        fetchCoinData();
        const intervalId = setInterval(fetchCoinData, 30000);

        return () => clearInterval(intervalId);
    }, []);
    
    const handleActionClick = (item) => {
        if (item.path) {
            navigate(item.path, { state: item.state });
        }
    };
    
    const MarketRow = ({ coin, isCommodity = false }: { coin: CryptoCoin; isCommodity?: boolean }) => {
        const isPositive = (coin.price_change_percentage_24h || 0) >= 0;
        const changeColor = isPositive ? 'text-green-500' : 'text-red-500';
        const changeSign = isPositive ? '+' : '';
        const pairSymbol = isCommodity ? `${coin.symbol.toUpperCase()}-USD` : `${coin.symbol.toUpperCase()}-USDT`;

        return (
            <div 
                className="grid grid-cols-3 items-center py-3 px-2 rounded-md hover:bg-slate-800/50 cursor-pointer transition-colors"
                onClick={() => navigate(`/trading/${pairSymbol}`)}
            >
                <div className="flex items-center gap-3">
                     {!isCommodity && coin.image ? (
                        <img src={coin.image} alt={coin.name} className="w-8 h-8 rounded-full" />
                    ) : (
                        <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center font-bold text-purple-400 flex-shrink-0">
                            {coin.symbol.slice(0, 2).toUpperCase()}
                        </div>
                    )}
                    <p className="font-bold truncate">{isCommodity ? coin.name : `${coin.symbol.toUpperCase()}/USDT`}</p>
                </div>
                <p className="text-center font-semibold">{coin.current_price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 6 })}</p>
                <p className={`text-right font-semibold ${changeColor}`}>{changeSign}{(coin.price_change_percentage_24h || 0).toFixed(2)}%</p>
            </div>
        );
    };

    return (
        <div className="bg-black text-white min-h-screen pb-24 font-sans">
            <header className="py-4">
                <h1 className="text-xl font-bold text-center">Home</h1>
            </header>

            <main className="px-4 space-y-6">
                {/* Hero Carousel */}
                <div className="relative w-full h-56 rounded-lg overflow-hidden shadow-lg">
                    {carouselImages.map((src, index) => (
                        <div
                            key={src}
                            className="absolute inset-0 w-full h-full bg-cover bg-center transition-opacity duration-1000 ease-in-out"
                            style={{
                                backgroundImage: `url('${src}')`,
                                opacity: index === currentImageIndex ? 1 : 0,
                            }}
                            aria-hidden={index !== currentImageIndex}
                        />
                    ))}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent"></div>
                    <div className="relative z-10 p-6 h-full flex flex-col justify-end text-white">
                        <h2 className="text-3xl font-bold leading-tight drop-shadow-md">Your Gateway to Digital Markets</h2>
                        <p className="text-gray-200 mt-2 max-w-md drop-shadow-sm">Trade with confidence and precision. The future of finance is here.</p>
                        <button
                            onClick={() => navigate('/trading')}
                            className="mt-4 px-6 py-2 bg-purple-600 text-white font-semibold rounded-lg hover:bg-purple-700 transition-colors shadow-lg self-start"
                        >
                            Start Trading Now
                        </button>
                    </div>
                     {/* Indicators */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10 flex space-x-2" role="tablist">
                        {carouselImages.map((_, index) => (
                            <button
                                key={index}
                                role="tab"
                                aria-selected={index === currentImageIndex}
                                aria-label={`Go to slide ${index + 1}`}
                                onClick={() => setCurrentImageIndex(index)}
                                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${index === currentImageIndex ? 'bg-white scale-125' : 'bg-white/50 hover:bg-white/75'}`}
                            />
                        ))}
                    </div>
                </div>

                {/* Announcement Bar */}
                <div className="flex items-center space-x-3 bg-slate-800/50 p-2 rounded-lg text-sm overflow-hidden">
                    <Volume2 size={20} className="text-purple-400 flex-shrink-0" />
                    <div className="flex-grow whitespace-nowrap">
                         <p className="animate-marquee inline-block">Upgrade Announcement: Trading fees for all BTC pairs reduced by 50% for a limited time!</p>
                    </div>
                    <button className="text-purple-400 font-semibold flex-shrink-0">More&gt;</button>
                </div>

                {/* Quick Action Menu */}
                <div className="grid grid-cols-4 gap-4 text-center">
                    {actionMenuItems.map((item, index) => (
                        <button key={index} onClick={() => handleActionClick(item)} className="flex flex-col items-center space-y-2">
                            <item.icon size={28} className="text-purple-400" />
                            <span className="text-sm font-medium">{item.label}</span>
                        </button>
                    ))}
                </div>

                {/* Market Data */}
                <div>
                    <div className="flex space-x-6 border-b border-slate-700 mb-2">
                         <button onClick={() => setActiveTab('Hot')} className={`py-2 font-semibold transition-colors ${activeTab === 'Hot' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}>
                            Hot
                        </button>
                         <button onClick={() => setActiveTab('Commodity')} className={`py-2 font-semibold transition-colors ${activeTab === 'Commodity' ? 'text-white border-b-2 border-purple-500' : 'text-gray-500'}`}>
                            Commodity
                        </button>
                    </div>

                    <div>
                        <div className="grid grid-cols-3 text-sm text-gray-500 mb-2 px-2">
                            <p className="text-left">Products</p>
                            <p className="text-center">Last price</p>
                            <p className="text-right">24H Change</p>
                        </div>
                        <div className="space-y-1">
                            {loading && activeTab === 'Hot' && <p className="text-center text-gray-400 py-4">Loading...</p>}
                            {!loading && activeTab === 'Hot' && marketData.map(coin => <MarketRow key={coin.id} coin={coin} />)}
                            {activeTab === 'Commodity' && commodityData.map(coin => <MarketRow key={coin.id} coin={coin} isCommodity={true} />)}
                        </div>
                         <div className="text-center mt-4">
                           <button onClick={() => navigate('/markets')} className="text-gray-500 hover:text-white transition-colors text-sm font-medium">
                               Check for more
                           </button>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
};

export default HomeScreen;
