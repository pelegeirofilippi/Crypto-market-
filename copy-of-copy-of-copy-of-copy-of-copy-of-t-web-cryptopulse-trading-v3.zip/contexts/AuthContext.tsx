
import * as React from 'react';
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import type { User, Notification, Transaction, ChatMessage } from '../types.ts';
import { apiLogin, apiSignup, apiGetUserByToken, apiDeposit, apiSubmitKyc, apiWithdraw, apiMarkAllNotificationsAsRead, apiMarkNotificationAsRead, apiCompleteTrade, apiUpdateChatHistory } from '../server/api.ts';

const AUTH_TOKEN_KEY = 'cryptoPulseAuthToken';

interface KYCData {
    fullName: string;
    dateOfBirth: string;
    country: string;
    address: string;
    idFrontBase64: string;
    idBackBase64: string;
}

interface UserDetails {
    dateOfBirth: string;
    country: string;
    address: string;
}

interface DepositDetails {
    amount: number;
    network: 'TRC20' | 'ERC20' | 'BTC';
    asset: string;
    transactionProof: string; // base64
}

interface WithdrawDetails {
    amount: number;
    address: string;
    asset: string;
}

interface TradeResultDetails {
    pair: string;
    direction: 'Buy' | 'Sell';
    stake: number;
    commission: number;
    profit: number;
    entryPrice: number;
    exitPrice: number;
    startTime: string;
}

interface AuthContextType {
  user: User | null;
  setUser: React.Dispatch<React.SetStateAction<User | null>>;
  isLoggedIn: boolean;
  isInitialized: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (name: string, email: string, password: string, details: UserDetails) => Promise<void>;
  logout: () => void;
  deposit: (details: DepositDetails) => Promise<void>;
  updateUserPhoto: (photoFile: File) => Promise<void>;
  submitKyc: (kycData: KYCData) => Promise<void>;
  withdraw: (password: string, details: WithdrawDetails) => Promise<void>;
  completeTrade: (details: TradeResultDetails) => Promise<void>;
  
  // Notification functions
  markAllNotificationsAsRead: () => Promise<void>;
  markNotificationAsRead: (notificationId: string) => Promise<void>;

  // AI Chat
  getAiChatResponse: (prompt: string) => Promise<void>;
}

const toBase64 = (file: File): Promise<string> => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
});


const AuthContext = React.createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
    const [user, setUser] = React.useState<User | null>(null);
    const [isInitialized, setIsInitialized] = React.useState(false);
    const [isLoading, setIsLoading] = React.useState(false);
    const [token, setToken] = React.useState<string | null>(() => localStorage.getItem(AUTH_TOKEN_KEY));
    const [ai, setAi] = React.useState<GoogleGenAI | null>(null);
    const [chat, setChat] = React.useState<Chat | null>(null);

    React.useEffect(() => {
        try {
            if (process.env.API_KEY) {
                const genAI = new GoogleGenAI({ apiKey: process.env.API_KEY });
                setAi(genAI);
            }
        } catch (error) {
            console.error("Failed to initialize GoogleGenAI", error);
        }
    }, []);

    const logout = React.useCallback(() => {
        setUser(null);
        setToken(null);
        setChat(null);
        localStorage.removeItem(AUTH_TOKEN_KEY);
    }, []);

    React.useEffect(() => {
        const initializeUser = async () => {
            if (token) {
                try {
                    setIsLoading(true);
                    const userData = await apiGetUserByToken(token);
                    setUser(userData);
                } catch (error) {
                    console.error("Initialization error:", error);
                    logout();
                } finally {
                    setIsLoading(false);
                }
            }
            setIsInitialized(true);
        };
        initializeUser();
    }, [token, logout]);

    React.useEffect(() => {
        if (ai && user && !chat) {
            const newChat = ai.chats.create({
                model: 'gemini-2.5-flash-preview-04-17',
                history: user.chatHistory || [],
                config: {
                    systemInstruction: `You are CryptoPulse AI, a helpful and friendly assistant for a cryptocurrency trading app.
                    The user you are talking to is ${user.name}.
                    Today's date is ${new Date().toLocaleDateString()}.
                    Always be concise and helpful.
                    Here is the user's current portfolio information, which you can use to answer questions:
                    - Balance: $${user.portfolio.balance.toFixed(2)}
                    - Pending Balance: $${user.portfolio.pendingBalance.toFixed(2)}
                    - P/L: $${user.portfolio.pl.toFixed(2)} (${user.portfolio.plPercentage.toFixed(2)}%)
                    - KYC Status: ${user.kycStatus}
                    Here are the user's last 5 transactions:
                    ${user.transactions.slice(0, 5).map(tx => `- ${tx.type} of ${tx.amount} ${tx.asset || ''} on ${new Date(tx.date).toLocaleDateString()}`).join('\n')}
                    Do not provide financial advice. When asked for financial advice, politely decline and state that you are an AI assistant.
                    For complex queries, you can suggest they contact human support via WhatsApp or Telegram links provided in the app.`,
                },
            });
            setChat(newChat);
        }
        if (!user && chat) {
            setChat(null);
        }
    }, [ai, user, chat]);

    const handleAuthSuccess = (userData: User, userToken: string) => {
        setUser(userData);
        setToken(userToken);
        localStorage.setItem(AUTH_TOKEN_KEY, userToken);
    };

    const login = async (email: string, password: string) => {
        setIsLoading(true);
        try {
            const { user: userData, token: userToken } = await apiLogin(email, password);
            handleAuthSuccess(userData, userToken);
        } finally {
            setIsLoading(false);
        }
    };

    const signup = async (name: string, email: string, password: string, details: UserDetails) => {
        setIsLoading(true);
        try {
            const { user: userData, token: userToken } = await apiSignup(name, email, password, details);
            handleAuthSuccess(userData, userToken);
        } finally {
            setIsLoading(false);
        }
    };
    
    const updateUserAndToken = React.useCallback(async () => {
        if (token) {
            const updatedUser = await apiGetUserByToken(token);
            setUser(updatedUser);
            return updatedUser;
        }
        throw new Error("No active session");
    }, [token]);
    
    const deposit = async (details: DepositDetails) => {
        if (!token) throw new Error("Not authenticated");
        setIsLoading(true);
        try {
            await apiDeposit(token, details);
            await updateUserAndToken();
        } finally {
            setIsLoading(false);
        }
    };
    
    const updateUserPhoto = async (photoFile: File) => {
        if (!user) throw new Error("Not authenticated");
        setIsLoading(true);
        try {
            const dataUrl = await toBase64(photoFile);
            // This is a mock. In a real app, you would upload this to a server.
            setUser(prev => prev ? { ...prev, photoURL: dataUrl } : null);
            // Here you would call an API like `apiUpdateUserPhoto(token, base64String)`
        } catch (error) {
            console.error("Failed to update photo", error);
            throw error;
        } finally {
            setIsLoading(false);
        }
    };
    
    const submitKyc = async (kycData: KYCData) => {
        if (!token) throw new Error("Not authenticated");
        setIsLoading(true);
        try {
            await apiSubmitKyc(token, kycData);
            await updateUserAndToken();
        } finally {
            setIsLoading(false);
        }
    };
    
    const withdraw = async (password: string, details: WithdrawDetails) => {
        if (!token) throw new Error("Not authenticated");
        setIsLoading(true);
        try {
            await apiWithdraw(token, password, details);
            await updateUserAndToken();
        } finally {
            setIsLoading(false);
        }
    };
    
    const completeTrade = async (details: TradeResultDetails) => {
        if (!token) return;
        try {
            const updatedUser = await apiCompleteTrade(token, details);
            setUser(updatedUser);
        } catch(e) {
            console.error("Failed to complete trade:", e);
            await updateUserAndToken();
        }
    };

    const markAllNotificationsAsRead = async () => {
        if (!token) throw new Error("Not authenticated");
        setIsLoading(true);
        try {
            const updatedUser = await apiMarkAllNotificationsAsRead(token);
            setUser(updatedUser);
        } finally {
            setIsLoading(false);
        }
    };

    const markNotificationAsRead = async (notificationId: string) => {
        if (!token) return;
        try {
            setUser(prev => {
                if (!prev) return null;
                const newNotifications = prev.notifications.map(n => n.id === notificationId ? { ...n, read: true } : n);
                return { ...prev, notifications: newNotifications };
            });
            await apiMarkNotificationAsRead(token, notificationId);
        } catch (error) {
            console.error("Failed to mark notification as read:", error);
            updateUserAndToken();
        }
    };

    const getAiChatResponse = async (prompt: string) => {
        if (!chat || !user || !token) throw new Error("Chat not initialized or user not logged in");
        setIsLoading(true);
        
        const userMessage: ChatMessage = { role: 'user', parts: [{ text: prompt }] };
        const updatedHistory: ChatMessage[] = [...(user.chatHistory || []), userMessage];
        
        setUser(prev => prev ? ({ ...prev, chatHistory: updatedHistory }) : null);

        try {
            const response = await chat.sendMessage({message:prompt});
            const modelMessage: ChatMessage = { role: 'model', parts: [{ text: response.text }] };
            const finalHistory = [...updatedHistory, modelMessage];
            
            setUser(prev => prev ? ({ ...prev, chatHistory: finalHistory }) : null);
            await apiUpdateChatHistory(token, finalHistory);

        } catch (error) {
            console.error("AI chat error:", error);
            const errorMessage: ChatMessage = { role: 'model', parts: [{ text: "Sorry, I encountered an error. Please try again." }] };
            const finalHistory = [...updatedHistory, errorMessage];
            setUser(prev => prev ? ({ ...prev, chatHistory: finalHistory }) : null);
        } finally {
            setIsLoading(false);
        }
    };

    const value: AuthContextType = {
        user,
        setUser,
        isLoggedIn: !!user,
        isInitialized,
        isLoading,
        login,
        signup,
        logout,
        deposit,
        updateUserPhoto,
        submitKyc,
        withdraw,
        completeTrade,
        markAllNotificationsAsRead,
        markNotificationAsRead,
        getAiChatResponse,
    };

    return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
    const context = React.useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};