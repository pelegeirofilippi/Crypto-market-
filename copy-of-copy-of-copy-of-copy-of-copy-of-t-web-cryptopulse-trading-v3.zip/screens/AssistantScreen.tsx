
import * as React from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { Send, User as UserIcon, Bot, Loader2 } from 'lucide-react';
import type { ChatMessage } from '../types.ts';

const ChatBubble = ({ message }: { message: ChatMessage }) => {
    const { user } = useAuth();
    const isUser = message.role === 'user';

    return (
        <div className={`flex items-end gap-3 my-4 ${isUser ? 'justify-end' : 'justify-start'}`}>
            {!isUser && (
                <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                    <Bot size={24} className="text-purple-400" />
                </div>
            )}
            <div className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl shadow-md break-words ${isUser ? 'bg-purple-600 text-white rounded-br-lg' : 'bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-bl-lg'}`}>
                <p className="text-sm">{message.parts[0].text}</p>
            </div>
            {isUser && (
                <div className="w-10 h-10 rounded-full bg-slate-500 flex items-center justify-center flex-shrink-0">
                    {user?.photoURL ? (
                        <img src={user.photoURL} alt="You" className="w-full h-full rounded-full object-cover" />
                    ) : (
                        <UserIcon size={24} className="text-white" />
                    )}
                </div>
            )}
        </div>
    );
};

const AssistantScreen = () => {
    const { user, getAiChatResponse, isLoading } = useAuth();
    const [input, setInput] = React.useState('');
    const chatContainerRef = React.useRef<null | HTMLDivElement>(null);
    
    // Determine if the AI is "thinking"
    const isAiThinking = React.useMemo(() => {
        if (!isLoading || !user?.chatHistory) return false;
        const lastMessage = user.chatHistory[user.chatHistory.length - 1];
        return lastMessage?.role === 'user';
    }, [isLoading, user?.chatHistory]);

    React.useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [user?.chatHistory, isAiThinking]);

    const handleSend = async (e?: React.FormEvent) => {
        if (e) e.preventDefault();
        if (input.trim() === '' || isLoading) return;
        const messageToSend = input;
        setInput('');
        await getAiChatResponse(messageToSend);
    };

    return (
        <div className="flex flex-col h-[calc(100vh-5rem)] bg-gray-50 dark:bg-black text-slate-900 dark:text-white">
            <header className="p-4 border-b border-gray-200 dark:border-slate-800 text-center flex-shrink-0">
                <h1 className="text-xl font-bold">AI Assistant</h1>
            </header>

            <main ref={chatContainerRef} className="flex-1 overflow-y-auto p-4 space-y-4">
                {user?.chatHistory && user.chatHistory.length > 0 ? (
                    user.chatHistory.map((msg, index) => (
                        <ChatBubble key={index} message={msg} />
                    ))
                ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center text-gray-500 dark:text-gray-400">
                        <Bot size={48} className="mb-4 text-purple-400" />
                        <h2 className="text-lg font-semibold text-slate-800 dark:text-slate-200">Welcome to CryptoPulse AI!</h2>
                        <p className="max-w-xs">Ask me anything about your account, transactions, or general platform features.</p>
                    </div>
                )}
                {isAiThinking && (
                    <div className="flex items-end gap-3 my-4 justify-start">
                        <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center flex-shrink-0">
                             <Bot size={24} className="text-purple-400" />
                        </div>
                        <div className="max-w-xs md:max-w-md lg:max-w-lg px-4 py-3 rounded-2xl shadow-md bg-white dark:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-bl-lg">
                            <div className="flex items-center space-x-2">
                                <Loader2 size={16} className="animate-spin text-purple-500" />
                                <span className="text-sm">Typing...</span>
                            </div>
                        </div>
                    </div>
                )}
            </main>

            <footer className="p-4 border-t border-gray-200 dark:border-slate-800 bg-white dark:bg-black flex-shrink-0">
                <form onSubmit={handleSend} className="flex items-center space-x-4">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Ask the AI assistant..."
                        className="flex-grow bg-gray-100 dark:bg-slate-800 border border-transparent rounded-full px-4 py-2 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
                        disabled={isLoading}
                        aria-label="Chat input"
                    />
                    <button
                        type="submit"
                        disabled={isLoading || input.trim() === ''}
                        className="bg-purple-600 text-white rounded-full p-3 hover:bg-purple-700 disabled:bg-purple-400 disabled:cursor-not-allowed transition-colors flex-shrink-0"
                        aria-label="Send message"
                    >
                        <Send size={20} />
                    </button>
                </form>
            </footer>
        </div>
    );
};

export default AssistantScreen;
